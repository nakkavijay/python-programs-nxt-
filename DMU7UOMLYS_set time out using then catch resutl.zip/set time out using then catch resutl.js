const myPromise = () => {
    return new Promise((resolve, decline) =>{
        setTimeout(() => {
            decline();
        }, 1000);
    });
};

myPromise()
.then(() => {
    console.log("success");
})
.catch(() => {
    console.log("Error");
    
})