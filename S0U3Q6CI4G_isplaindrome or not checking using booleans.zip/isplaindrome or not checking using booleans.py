name = 'wow'
"""isplaindrome = name.find(name[::-1])==0
print(isplaindrome)"""

isplaindrome = name.find(name[::-1]) == 0
print(isplaindrome)