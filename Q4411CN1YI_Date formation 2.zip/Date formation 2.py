#Read time
time = int(input(""))
#get days
days = time // (24 * 3600)
time = time % (24 * 3600)
#get hour
hour = time // 3600
time %= 3600
#get minutes
minutes = time // 60
time %= 60
#get seconds
seconds = time

#Print only the non-zero values.
outputTime=""
if days>0:
    outputTime=str(days)+" Days "
if hour>0:
    outputTime+=str(hour)+" Hours "
if minutes>0:
    outputTime+=str(minutes)+" Minutes "
if seconds>0:
    outputTime+=str(seconds)+" Seconds "
#Display time
print(outputTime)