const url = "h://kes/random";


const fetchData = async() => {
    try{
        const fetchResult = await fetch(url);
        console.log("Fetching done");
        
    }catch(err) {
        console.log(err);
    }
};

fetchData();