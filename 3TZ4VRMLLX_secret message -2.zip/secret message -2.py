def main():
    #Read basestring
    inputString = input()
    outputString = ""
    for letter in inputString:
        number = getNumber(letter)
        if(number != -1):
            outputString += str(number) + "-"
        else:
            outputString += letter
            
    print(outputString[:-1])
# this function convert letter to number
def getNumber(letter):
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    for i in range(0, len(alphabet)):
        if letter.islower() and letter==alphabet[i]:
            return i + 1
        if letter.isupper() and letter==alphabet[i].upper():
            return i + 1
            
    return -1
    
main()