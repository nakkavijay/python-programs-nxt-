mesg = "this is a really " \
"long string" 
print(mesg)