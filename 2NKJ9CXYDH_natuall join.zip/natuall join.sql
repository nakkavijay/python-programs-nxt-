#Question 1:
Get the details of the instructor who is teaching "Cyber Security".


SELECT
  instructor.full_name,
  instructor.gender
FROM
  course NATURAL
  JOIN instructor
WHERE
  instructor.full_name = "Alex";