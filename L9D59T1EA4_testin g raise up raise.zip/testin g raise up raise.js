const myPromise = new Promise((resolve, reject) => {
    console.log("Raise Up!");
    
});
console.log("Great!! keeep going");