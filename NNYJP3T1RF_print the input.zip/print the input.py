#print the input
a = input()
print(a)