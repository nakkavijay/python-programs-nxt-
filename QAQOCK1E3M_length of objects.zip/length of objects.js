let racer = {
    lapTimes: [23, 24.5, 22],
    isWinner : true
};
racer.lapTimes.push(21.5);
totalLaps = racer.lapTimes.length;
console.log(totalLaps)