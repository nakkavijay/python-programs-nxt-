numbersStr=input("").split(' ')
sumPN=0
for number in numbersStr:
    number=int(number)
    is_prime=True
    if number > 1:
        for i in range(2, number):
            if (number % i) == 0:
                is_prime=False
                break
        if is_prime:
            #calculate the sum of all prime numbers from 1 to N.
            sumPN=sumPN+number


#Display the result
print(str(sumPN))