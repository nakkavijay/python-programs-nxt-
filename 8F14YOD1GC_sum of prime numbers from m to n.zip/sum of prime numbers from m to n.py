# sum of prime numbers 
m, n = int(input()), int(input())
sum = 0
for i in range(m, n+1):
    flag = False
    for j in range (2, i):
        if i % j == 0:
            flag = True
    if flag == False and i != 1:
            sum += i
print(sum)