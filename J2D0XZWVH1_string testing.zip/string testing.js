let myar = [23,"5", 56, true, 8];
let concatenate = myar[1] + myar[4];
console.log(typeof(concatenate));