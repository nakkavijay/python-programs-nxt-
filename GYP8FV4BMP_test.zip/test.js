let person = {
    name: "sunder pichai",
    age : 34,
    car: {
        company : "BMW",
        model:"x5"
    }
};


console.log(typeof(person.car.model));