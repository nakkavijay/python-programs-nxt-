sum = 10
def calculate():
    sum = 30
    sum = sum + 20
    currentSum = 200
    totalSum = sum + currentSum
    print(totalSum)
calculate()
print(sum)