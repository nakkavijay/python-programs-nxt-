const promise  = new Promise((resolve, reject) => {
    setTimeout(()  => 
        resolve("reject!")
    , 1000);
});
const myFunction = async () => {
    try{
        let result = await promise;
        result = "Got this!";
        console.log(result);
        
    } catch(error){
        console.log(error);
    }
};
myFunction();