"""odd_squares = []
for i in range(20):
    if i % 2 == 0:
        odd_squares.append(i**2)
print(odd_squares)"""

"""odd_squares = [i**2 for i in range(11) if i%2==1]
print(odd_squares)"""


even_squares = [i**2 for i in range(20) if i %2 ==0]
print(even_squares)

even_cube = [i**3 for i in range(20) if i % 2 ==0]
print(even_cube)