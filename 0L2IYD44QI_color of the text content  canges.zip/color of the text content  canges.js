let headingElement = document.getElementById("mainHeading");
headingElement.classList.remove("main-heading");
headingElement.classList.add("heading-styles");