function getSeconds() {
    let hours = parseInt(document.getElementById('hoursInput').value);
    let minutes = parseInt(document.getElementById('minutesInput').value);
    let seconds = (hours * 60 + minutes) * 60;
    console.log(hours);
    let showSeconds = document.getElementById("timeInSeconds");
    let showError = document.getElementById("errorMsg");
    if (isNaN(hours) || isNaN(minutes)) {
        showError.textContent = "Error!!! Please enter any value"
        showSeconds.textContent = "";

    } else {

        showSeconds.textContent = "the number in seconds " + seconds;
        showError.textContent = "";

    }

};
showError.addEventListener("click", getSeconds);
document.body.appendChild(showError);