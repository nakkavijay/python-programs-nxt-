name = 'Kim Kardashians'
print(name)
names = 'Kim Kardasshiha'[::-1]
print(names)