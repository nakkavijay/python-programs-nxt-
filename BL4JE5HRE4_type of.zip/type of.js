let footballer = {
    team: "India",
    "is goalkeeper" : true
};
console.log(typeof(footballer["is goalkeeper"]));