a = [int(i) for i in input().split()]
b = int(input())
index = 0
for i in range(len(a)):
    if a[i] == b:
        index = i
print(index)