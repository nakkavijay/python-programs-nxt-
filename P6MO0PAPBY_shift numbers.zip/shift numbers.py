str = input()
digits =''
letters = ''

for c in str:
    if c.isdigit():
        digits += c
    else:
        letters += c
print(digits+letters)