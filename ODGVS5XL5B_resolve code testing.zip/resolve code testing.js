const myPromise = () => {
    return new Promise(function (reject, resolve){
        reject();
    });
};
myPromise()
.then(() => {
    console.log("call back fucntion reslove");
    
})
.catch(() => {
    console.log("cal  rejet");
})