sum = 10
def calculate():
    global sum 
    sum = sum +20
    cureentSUm = 200
    totalSum = sum + cureentSUm
    print(totalSum)
    
calculate()
print(sum)