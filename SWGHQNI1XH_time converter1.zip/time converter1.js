function convertToSeconds(hours, minutes) {
    var hours = document.getElementById("hoursInput").value;
    var minutes = +document.getElementById("minutesInput").value;
    var totalsec;
    totalsec = ((hours) * 60 + minutes) * 60
    document.getElementById("convertBtn").innerHTML = totalsec + " seconds"
}