let myArray = [4,2,"hari"];
myArray[myArray.length] = "rahul";
console.log(myArray.length);