subs = 2400
likes = 200
comment = 56

'''  1 case :     if subs > 150 and likes > 100 and comment > 50:
    print("Awsome Video")
    
    output is Awsome video
    '''
''' 2 case:     conditions = [
    subs > 150,
    likes > 100,
    comment> 50
    ]
    
if all(conditions):
    print("Awsome")
    
    output Awsome'''
    
    
'''if subs > 150 or likes > 100 or comment > 50:
    print("Awsome video")
    output Awsome video'''
    
    
'''checkers = [
    subs > 2000,
    likes > 100,
    comment> 50]
if any(checkers):
    print("Awsome video")'''

'''print(subs,likes)
temp = subs
subs = likes
likes = temp
print(subs,likes)
output 2400 200
200 2400'''


print(subs, likes)
#swapping 
subs, likes = likes, subs
print(subs, likes)