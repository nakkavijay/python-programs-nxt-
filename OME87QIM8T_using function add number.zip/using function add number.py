# functions
def sum(*a):
    result = 0
    for i in a:
        result = result + i
    return result
    
res = sum(1,3,4,5,6,6,7,7,7)
print(res)