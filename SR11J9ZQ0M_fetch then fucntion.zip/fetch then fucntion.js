const url = "https://apis.ccbp.in/jokes/random";
fetch(url)
.then((response) => {
    return response.json();
    
})
.then((jsonData) => {
    console.log("Data Loaded");
    
});
console.log("Data Fetched");