const myPromise = new Promise((resolve, reject) => {
    console.log("Blue");
});
console.log("Green");
myPromise
.then(() => {
    console.log("Orange");
});
console.log("White");